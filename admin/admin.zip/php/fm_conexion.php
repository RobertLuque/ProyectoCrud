<?php
//$enlace = mysqli_connect("127.0.0.1", "mi_usuario", "mi_contraseña", "mi_bd");
$enlace = mysqli_connect("localhost", "root", "1234", "femulp");
$enlace->set_charset("utf8");
 //Para reconocer caracteres especiales

?>